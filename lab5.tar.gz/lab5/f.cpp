#ifndef F_IS_DEFINED
#define F_IS_DEFINED

int f(){
  return 4;
}
#endif
